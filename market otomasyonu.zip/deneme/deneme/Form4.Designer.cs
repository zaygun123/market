﻿namespace deneme
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button12 = new System.Windows.Forms.Button();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.EKMEK = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button21 = new System.Windows.Forms.Button();
            this.ımageList2 = new System.Windows.Forms.ImageList(this.components);
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button27 = new System.Windows.Forms.Button();
            this.ımageList3 = new System.Windows.Forms.ImageList(this.components);
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(16, 73);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(284, 299);
            this.dataGridView1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button12);
            this.groupBox1.Controls.Add(this.button11);
            this.groupBox1.Controls.Add(this.button10);
            this.groupBox1.Controls.Add(this.button9);
            this.groupBox1.Controls.Add(this.button8);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.EKMEK);
            this.groupBox1.Location = new System.Drawing.Point(513, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(450, 254);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // button12
            // 
            this.button12.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button12.ImageKey = "nar.jpg";
            this.button12.ImageList = this.ımageList1;
            this.button12.Location = new System.Drawing.Point(341, 174);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(101, 72);
            this.button12.TabIndex = 11;
            this.button12.Text = "NAR";
            this.button12.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button12.UseVisualStyleBackColor = true;
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "lira.jpg");
            this.ımageList1.Images.SetKeyName(1, "kredi.jpg");
            this.ımageList1.Images.SetKeyName(2, "wallet.jpg");
            this.ımageList1.Images.SetKeyName(3, "ekmek.jpg");
            this.ımageList1.Images.SetKeyName(4, "elma.jpg");
            this.ımageList1.Images.SetKeyName(5, "havuç.jpg");
            this.ımageList1.Images.SetKeyName(6, "ıspanak.jpg");
            this.ımageList1.Images.SetKeyName(7, "limon.jpg");
            this.ımageList1.Images.SetKeyName(8, "maydanoz.jpg");
            this.ımageList1.Images.SetKeyName(9, "muz.jpg");
            this.ımageList1.Images.SetKeyName(10, "nar.jpg");
            this.ımageList1.Images.SetKeyName(11, "patates.jpg");
            this.ımageList1.Images.SetKeyName(12, "portokal.jpg");
            this.ımageList1.Images.SetKeyName(13, "portakal.jpg");
            this.ımageList1.Images.SetKeyName(14, "soğan.jpg");
            // 
            // button11
            // 
            this.button11.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button11.ImageKey = "portokal.jpg";
            this.button11.ImageList = this.ımageList1;
            this.button11.Location = new System.Drawing.Point(234, 174);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(101, 72);
            this.button11.TabIndex = 10;
            this.button11.Text = "MANDALİNA";
            this.button11.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button10.ImageKey = "maydanoz.jpg";
            this.button10.ImageList = this.ımageList1;
            this.button10.Location = new System.Drawing.Point(127, 174);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(101, 72);
            this.button10.TabIndex = 9;
            this.button10.Text = "MAYDANOZ";
            this.button10.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button9.ImageKey = "ıspanak.jpg";
            this.button9.ImageList = this.ımageList1;
            this.button9.Location = new System.Drawing.Point(20, 174);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(101, 72);
            this.button9.TabIndex = 8;
            this.button9.Text = "ISPANAK";
            this.button9.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button8.ImageKey = "limon.jpg";
            this.button8.ImageList = this.ımageList1;
            this.button8.Location = new System.Drawing.Point(341, 96);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(101, 72);
            this.button8.TabIndex = 7;
            this.button8.Text = "LİMON";
            this.button8.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button7.ImageKey = "havuç.jpg";
            this.button7.ImageList = this.ımageList1;
            this.button7.Location = new System.Drawing.Point(234, 96);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(101, 72);
            this.button7.TabIndex = 6;
            this.button7.Text = "HAVUÇ";
            this.button7.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button6.ImageKey = "soğan.jpg";
            this.button6.ImageList = this.ımageList1;
            this.button6.Location = new System.Drawing.Point(127, 96);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(101, 72);
            this.button6.TabIndex = 5;
            this.button6.Text = "SOĞAN";
            this.button6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button5.ImageKey = "patates.jpg";
            this.button5.ImageList = this.ımageList1;
            this.button5.Location = new System.Drawing.Point(20, 96);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(101, 72);
            this.button5.TabIndex = 4;
            this.button5.Text = "PATATES";
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button4.ImageKey = "muz.jpg";
            this.button4.ImageList = this.ımageList1;
            this.button4.Location = new System.Drawing.Point(341, 19);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(101, 72);
            this.button4.TabIndex = 3;
            this.button4.Text = "MUZ";
            this.button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button3.ImageKey = "portakal.jpg";
            this.button3.ImageList = this.ımageList1;
            this.button3.Location = new System.Drawing.Point(234, 19);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 72);
            this.button3.TabIndex = 2;
            this.button3.Text = "PORTAKAL";
            this.button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.ImageKey = "elma.jpg";
            this.button2.ImageList = this.ımageList1;
            this.button2.Location = new System.Drawing.Point(127, 18);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 72);
            this.button2.TabIndex = 1;
            this.button2.Text = "ELMA";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // EKMEK
            // 
            this.EKMEK.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.EKMEK.ImageKey = "ekmek.jpg";
            this.EKMEK.ImageList = this.ımageList1;
            this.EKMEK.Location = new System.Drawing.Point(20, 20);
            this.EKMEK.Name = "EKMEK";
            this.EKMEK.Size = new System.Drawing.Size(101, 61);
            this.EKMEK.TabIndex = 0;
            this.EKMEK.Text = "EKMEK";
            this.EKMEK.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.EKMEK.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button15);
            this.groupBox2.Controls.Add(this.button14);
            this.groupBox2.Controls.Add(this.button13);
            this.groupBox2.Location = new System.Drawing.Point(5, 378);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(224, 101);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // button15
            // 
            this.button15.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button15.ImageKey = "wallet.jpg";
            this.button15.ImageList = this.ımageList1;
            this.button15.Location = new System.Drawing.Point(152, 13);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(67, 72);
            this.button15.TabIndex = 2;
            this.button15.Text = "KART -     NAKİT";
            this.button15.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button14.ImageKey = "kredi.jpg";
            this.button14.ImageList = this.ımageList1;
            this.button14.Location = new System.Drawing.Point(79, 13);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(67, 72);
            this.button14.TabIndex = 1;
            this.button14.Text = "KREDİ KARTI";
            this.button14.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button13.ImageKey = "lira.jpg";
            this.button13.ImageList = this.ımageList1;
            this.button13.Location = new System.Drawing.Point(6, 13);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(67, 72);
            this.button13.TabIndex = 0;
            this.button13.Text = "NAKİT";
            this.button13.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(22, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "Ürün Adı";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(25, 33);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(123, 20);
            this.textBox1.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "BARKOD";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(163, 33);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(37, 20);
            this.textBox2.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(160, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "MİKTAR";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(21, 337);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 24);
            this.label4.TabIndex = 8;
            this.label4.Text = "TOPLAM";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(115, 337);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 24);
            this.label5.TabIndex = 9;
            this.label5.Text = "0 ₺                  ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Controls.Add(this.button21);
            this.groupBox3.Controls.Add(this.button20);
            this.groupBox3.Controls.Add(this.button19);
            this.groupBox3.Controls.Add(this.button18);
            this.groupBox3.Controls.Add(this.button17);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Location = new System.Drawing.Point(306, 37);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(90, 388);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(4, 351);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 20);
            this.label7.TabIndex = 7;
            this.label7.Text = "Para Üstü";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBox3.Location = new System.Drawing.Point(6, 313);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(79, 22);
            this.textBox3.TabIndex = 6;
            this.textBox3.Text = "Ödenen";
            // 
            // button21
            // 
            this.button21.ImageKey = "200.jpg";
            this.button21.ImageList = this.ımageList2;
            this.button21.Location = new System.Drawing.Point(6, 250);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(73, 40);
            this.button21.TabIndex = 5;
            this.button21.UseVisualStyleBackColor = true;
            // 
            // ımageList2
            // 
            this.ımageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList2.ImageStream")));
            this.ımageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList2.Images.SetKeyName(0, "5.jpg");
            this.ımageList2.Images.SetKeyName(1, "10.jpg");
            this.ımageList2.Images.SetKeyName(2, "20.jpg");
            this.ımageList2.Images.SetKeyName(3, "50.jpg");
            this.ımageList2.Images.SetKeyName(4, "100.jpg");
            this.ımageList2.Images.SetKeyName(5, "200.jpg");
            // 
            // button20
            // 
            this.button20.ImageKey = "50.jpg";
            this.button20.ImageList = this.ımageList2;
            this.button20.Location = new System.Drawing.Point(6, 160);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(73, 40);
            this.button20.TabIndex = 4;
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.ImageKey = "100.jpg";
            this.button19.ImageList = this.ımageList2;
            this.button19.Location = new System.Drawing.Point(6, 204);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(73, 40);
            this.button19.TabIndex = 3;
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.ImageIndex = 2;
            this.button18.ImageList = this.ımageList2;
            this.button18.Location = new System.Drawing.Point(6, 114);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(73, 40);
            this.button18.TabIndex = 2;
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.ImageKey = "10.jpg";
            this.button17.ImageList = this.ımageList2;
            this.button17.Location = new System.Drawing.Point(6, 68);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(73, 40);
            this.button17.TabIndex = 1;
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.ImageKey = "5.jpg";
            this.button1.ImageList = this.ımageList2;
            this.button1.Location = new System.Drawing.Point(6, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(73, 40);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button27);
            this.groupBox4.Controls.Add(this.button26);
            this.groupBox4.Controls.Add(this.button25);
            this.groupBox4.Controls.Add(this.button24);
            this.groupBox4.Controls.Add(this.button23);
            this.groupBox4.Controls.Add(this.button22);
            this.groupBox4.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox4.Location = new System.Drawing.Point(437, 359);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(494, 120);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "promosyonlar";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // button27
            // 
            this.button27.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button27.ImageKey = "çay.jpg";
            this.button27.ImageList = this.ımageList3;
            this.button27.Location = new System.Drawing.Point(430, 19);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(77, 82);
            this.button27.TabIndex = 5;
            this.button27.Text = "65 ₺";
            this.button27.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // ımageList3
            // 
            this.ımageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList3.ImageStream")));
            this.ımageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList3.Images.SetKeyName(0, "samp.jpg");
            this.ımageList3.Images.SetKeyName(1, "çiko.jpg");
            this.ımageList3.Images.SetKeyName(2, "det.jpg");
            this.ımageList3.Images.SetKeyName(3, "mama.jpg");
            this.ımageList3.Images.SetKeyName(4, "yağ.jpg");
            this.ımageList3.Images.SetKeyName(5, "çay.jpg");
            // 
            // button26
            // 
            this.button26.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button26.ImageKey = "yağ.jpg";
            this.button26.ImageList = this.ımageList3;
            this.button26.Location = new System.Drawing.Point(349, 20);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(77, 81);
            this.button26.TabIndex = 4;
            this.button26.Text = "60 ₺";
            this.button26.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button25.ImageKey = "mama.jpg";
            this.button25.ImageList = this.ımageList3;
            this.button25.Location = new System.Drawing.Point(266, 19);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(77, 82);
            this.button25.TabIndex = 3;
            this.button25.Text = "70 ₺";
            this.button25.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button24.ImageKey = "det.jpg";
            this.button24.ImageList = this.ımageList3;
            this.button24.Location = new System.Drawing.Point(183, 20);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(77, 81);
            this.button24.TabIndex = 2;
            this.button24.Text = "40 ₺";
            this.button24.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button23.ImageKey = "çiko.jpg";
            this.button23.ImageList = this.ımageList3;
            this.button23.Location = new System.Drawing.Point(100, 20);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(77, 81);
            this.button23.TabIndex = 1;
            this.button23.Text = "30 ₺";
            this.button23.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button22.ImageKey = "samp.jpg";
            this.button22.ImageList = this.ımageList3;
            this.button22.Location = new System.Drawing.Point(17, 20);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(77, 81);
            this.button22.TabIndex = 0;
            this.button22.Text = "20 ₺";
            this.button22.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button22.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(164, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 18);
            this.label6.TabIndex = 12;
            this.label6.Text = "adet";
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button16.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button16.ImageKey = "(yok)";
            this.button16.ImageList = this.ımageList1;
            this.button16.Location = new System.Drawing.Point(6, 16);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(80, 57);
            this.button16.TabIndex = 13;
            this.button16.Text = "İADE VE DEĞİŞİM";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button31);
            this.groupBox5.Controls.Add(this.button30);
            this.groupBox5.Controls.Add(this.button29);
            this.groupBox5.Controls.Add(this.button16);
            this.groupBox5.Location = new System.Drawing.Point(402, 54);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(92, 273);
            this.groupBox5.TabIndex = 14;
            this.groupBox5.TabStop = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button29.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button29.ImageKey = "(yok)";
            this.button29.ImageList = this.ımageList1;
            this.button29.Location = new System.Drawing.Point(6, 79);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(80, 57);
            this.button29.TabIndex = 15;
            this.button29.Text = "FİŞ YAZDIRMA";
            this.button29.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button30.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button30.ImageKey = "(yok)";
            this.button30.ImageList = this.ımageList1;
            this.button30.Location = new System.Drawing.Point(6, 142);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(80, 57);
            this.button30.TabIndex = 16;
            this.button30.Text = "MÜŞTERİ GİRİŞİ";
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button31.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button31.ImageKey = "(yok)";
            this.button31.ImageList = this.ımageList1;
            this.button31.Location = new System.Drawing.Point(6, 205);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(80, 57);
            this.button31.TabIndex = 17;
            this.button31.Text = "YENİ KAYIT";
            this.button31.UseVisualStyleBackColor = false;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 517);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button EKMEK;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.ImageList ımageList2;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.ImageList ımageList3;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
    }
}