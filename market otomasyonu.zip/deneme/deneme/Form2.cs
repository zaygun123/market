﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace deneme
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void kullanıcılar_SelectedIndexChanged(object sender, EventArgs e)
        {
            kullanıcılar.Items.Add("esma nur");
            kullanıcılar.Items.Add("merve");
            kullanıcılar.Items.Add("zeynep");
            kullanıcılar.Items.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
