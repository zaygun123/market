﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace deneme
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        bool nakit =false;
        private void Form4_Load(object sender, EventArgs e)
        {
            groupBox3.Visible = false;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            nakit = true;
            if (nakit == true)
            {
                groupBox3.Visible = true;
            }
            else if(nakit==false)
            {
                groupBox3.Visible = false;
            }

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {
            
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void button27_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();//açılacak form

            form5.Show(); //form 5 açılıyor.
        }
    }
}
